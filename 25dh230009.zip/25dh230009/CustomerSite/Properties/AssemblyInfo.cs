using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CustomerSite")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CustomerSite")]
[assembly: ComVisible(false)]
[assembly: Guid("9c61a1e2-2a71-4b5e-8f9a-7a2a6f5f41a1")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
