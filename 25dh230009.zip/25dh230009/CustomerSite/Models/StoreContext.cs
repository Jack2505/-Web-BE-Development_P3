using System.Data.Entity;

namespace CustomerSite.Models
{
    public class StoreContext : DbContext
    {
        public StoreContext() : base("MyStoreConnection") { }
        public DbSet<User> Users { get; set; }
        public DbSet<Customer> Customers { get; set; }
    }
}
