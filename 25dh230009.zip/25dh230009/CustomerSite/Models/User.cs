using System.ComponentModel.DataAnnotations;

namespace CustomerSite.Models
{
    public class User
    {
        [Key]
        public int UserID { get; set; }

        [Required, StringLength(50)]
        public string Username { get; set; }

        [Required]
        public string PasswordHash { get; set; }

        [StringLength(20)]
        public string Role { get; set; }
    }
}
