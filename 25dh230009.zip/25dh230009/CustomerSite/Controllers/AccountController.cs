using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web.Mvc;
using System.Web.Security;
using CustomerSite.Models;
using CustomerSite.Models.ViewModels;

namespace CustomerSite.Controllers
{
    public class AccountController : Controller
    {
        private readonly StoreContext db = new StoreContext();

        private string HashPassword(string password)
        {
            using (var sha = SHA256.Create())
            {
                var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        [HttpGet]
        public ActionResult Register()
        {
            if (User.Identity.IsAuthenticated) return RedirectToAction("Index", "Home");
            return View(new RegisterVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(RegisterVM model)
        {
            if (!ModelState.IsValid) return View(model);
            if (db.Users.Any(u => u.Username == model.Username.Trim()))
            {
                ModelState.AddModelError("Username", "Tên đăng nhập đã tồn tại");
                return View(model);
            }

            var username = model.Username.Trim();
            db.Users.Add(new User { Username = username, PasswordHash = HashPassword(model.Password), Role = "Customer" });
            db.Customers.Add(new Customer
            {
                Username = username,
                FullName = model.FullName.Trim(),
                Phone = model.Phone,
                Email = model.Email,
                Address = model.Address
            });
            db.SaveChanges();
            TempData["Success"] = "Đăng ký tài khoản thành công. Vui lòng đăng nhập.";
            return RedirectToAction("Login");
        }

        [HttpGet]
        public ActionResult Login(string returnUrl)
        {
            if (User.Identity.IsAuthenticated) return RedirectToAction("Index", "Home");
            ViewBag.ReturnUrl = returnUrl;
            return View(new LoginVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginVM model, string returnUrl)
        {
            if (!ModelState.IsValid) return View(model);
            var user = db.Users.SingleOrDefault(u => u.Username == model.Username.Trim());
            if (user == null || user.PasswordHash != HashPassword(model.Password))
            {
                ModelState.AddModelError("", "Tên đăng nhập hoặc mật khẩu không đúng");
                return View(model);
            }

            Session["Username"] = user.Username;
            FormsAuthentication.SetAuthCookie(user.Username, model.RememberMe);
            if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl)) return Redirect(returnUrl);
            return RedirectToAction("Index", "Home");
        }

        [Authorize]
        [HttpGet]
        public ActionResult ProfileInfo()
        {
            var username = User.Identity.Name;
            var customer = db.Customers.SingleOrDefault(c => c.Username == username);
            if (customer == null) return HttpNotFound();
            return View(new ProfileVM
            {
                Username = customer.Username,
                FullName = customer.FullName,
                Phone = customer.Phone,
                Email = customer.Email,
                Address = customer.Address
            });
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ProfileInfo(ProfileVM model)
        {
            if (!ModelState.IsValid) return View(model);
            var customer = db.Customers.SingleOrDefault(c => c.Username == User.Identity.Name);
            if (customer == null) return HttpNotFound();
            customer.FullName = model.FullName.Trim();
            customer.Phone = model.Phone;
            customer.Email = model.Email;
            customer.Address = model.Address;
            db.SaveChanges();
            TempData["Success"] = "Cập nhật thông tin thành công";
            return RedirectToAction("ProfileInfo");
        }

        [Authorize]
        public ActionResult Logout()
        {
            Session.Clear();
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}
